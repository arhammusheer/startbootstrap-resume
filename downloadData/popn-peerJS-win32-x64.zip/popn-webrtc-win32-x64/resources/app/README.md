
# popN webchat
A simple chat app based on electron and peer JS which connects peers using the peer ID provided by peer JS api. 

## Usage
Clone the repository

`git clone https://github.com/arhammusheer/popn-peerJS`

Install Dependencies

`npm install`

Run the app

`npm start`

